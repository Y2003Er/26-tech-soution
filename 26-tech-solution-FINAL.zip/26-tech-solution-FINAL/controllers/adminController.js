// ═══════════════════════════════════════════
// 26-TECH ADMIN CONTROLLER (TELEGRAM COMPATIBLE)
// ═══════════════════════════════════════════

const AppModel = require('../models/appModel');
const AdminModel = require('../models/adminModel');
const TelegramService = require('../telegramService');

function makeSlug(name) {
  return name.toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

const AdminController = {

  loginPage(req, res) {
    if (req.session.admin) return res.redirect('/admin');
    res.render('admin/login', {
      title: 'Admin Login - 26 Tech',
      error: req.flash('error'),
      success: req.flash('success'),
    });
  },

  async loginPost(req, res) {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        req.flash('error', 'Jaza sehemu zote.');
        return res.redirect('/admin/login');
      }

      const admin = await AdminModel.findByEmail(email);
      if (!admin) {
        req.flash('error', 'Email au nywila si sahihi.');
        return res.redirect('/admin/login');
      }

      const ok = await AdminModel.verifyPassword(password, admin.password);
      if (!ok) {
        req.flash('error', 'Email au nywila si sahihi.');
        return res.redirect('/admin/login');
      }

      req.session.admin = { id: admin.id, email: admin.email, username: admin.username };

      req.session.save((err) => {
        if (err) {
          console.error('Session save error:', err);
          req.flash('error', 'Hitilafu ya seva.');
          return res.redirect('/admin/login');
        }
        res.redirect('/admin');
      });

    } catch (err) {
      console.error('login error:', err);
      req.flash('error', 'Hitilafu ya seva.');
      res.redirect('/admin/login');
    }
  },

  signupPage(req, res) {
    if (req.session.admin) return res.redirect('/admin');
    res.render('admin/signup', {
      title: 'Sajili Admin - 26 Tech',
      error: req.flash('error'),
    });
  },

  async signupPost(req, res) {
    try {
      const { email, username, password, confirmPassword } = req.body;

      if (!email || !password || !confirmPassword) {
        req.flash('error', 'Jaza sehemu zote zinazohitajika.');
        return res.redirect('/admin/signup');
      }

      if (!isValidEmail(email)) {
        req.flash('error', 'Email si sahihi.');
        return res.redirect('/admin/signup');
      }

      if (password.length < 6) {
        req.flash('error', 'Nywila lazima iwe na herufi 6 au zaidi.');
        return res.redirect('/admin/signup');
      }

      if (password !== confirmPassword) {
        req.flash('error', 'Nywila hazifanani.');
        return res.redirect('/admin/signup');
      }

      const exists = await AdminModel.emailExists(email);
      if (exists) {
        req.flash('error', 'Email hii tayari imesajiliwa.');
        return res.redirect('/admin/signup');
      }

      await AdminModel.create({ email, password, username });

      req.flash('success', 'Akaunti imeundwa! Sasa ingia kwa email na nywila yako.');
      res.redirect('/admin/login');

    } catch (err) {
      console.error('signup error:', err);
      req.flash('error', 'Hitilafu ya seva. Jaribu tena.');
      res.redirect('/admin/signup');
    }
  },

  logout(req, res) {
    req.session.destroy(() => res.redirect('/admin/login'));
  },

  async dashboard(req, res) {
    try {
      const [apps, stats] = await Promise.all([
        AppModel.adminGetAll(),
        AppModel.getStats(),
      ]);
      res.render('admin/dashboard', {
        title: 'Admin Dashboard - 26 Tech',
        admin: req.session.admin,
        apps,
        stats,
        success: req.flash('success'),
        error: req.flash('error'),
      });
    } catch (err) {
      console.error('dashboard error:', err);
      res.status(500).render('error', { message: 'Hitilafu ya seva.' });
    }
  },

  newAppPage(req, res) {
    res.render('admin/app-form', {
      title: 'Ongeza App - 26 Tech',
      admin: req.session.admin,
      app: null,
      error: req.flash('error'),
    });
  },

  async createApp(req, res) {
    try {
      const { name, category, description, version,
              file_size, os, is_free, download_url, is_featured, icon_file_id } = req.body;

      if (!name || !category || !description || !download_url) {
        req.flash('error', 'Jaza sehemu zote zinazohitajika.');
        return res.redirect('/admin/apps/new');
      }

      const slug = makeSlug(name);

      await AppModel.create({
        name, slug, category,
        description, version: version || 'v1.0',
        file_size: file_size || '-',
        os: os || 'Windows',
        is_free: is_free === 'true',
        download_url: download_url.trim(),
        is_featured: is_featured === 'true',
        is_active: true,
        icon_file_id: icon_file_id ? icon_file_id.trim() : null
      });

      req.flash('success', `"${name}" imeongezwa.`);
      res.redirect('/admin');
    } catch (err) {
      console.error('createApp error:', err);
      req.flash('error', err.message.includes('unique') ? 'Jina hili lipo tayari.' : 'Hitilafu ya seva.');
      res.redirect('/admin/apps/new');
    }
  },

  async editAppPage(req, res) {
    try {
      const appId = parseInt(req.params.id);
      const app = await AppModel.getById(appId);
      if (!app) {
        req.flash('error', 'App haikupatikana.');
        return res.redirect('/admin');
      }
      res.render('admin/app-form', {
        title: `Hariri ${app.name} - 26 Tech`,
        admin: req.session.admin,
        app,
        error: req.flash('error'),
      });
    } catch (err) {
      res.status(500).render('error', { message: 'Hitilafu ya seva.' });
    }
  },

  async updateApp(req, res) {
    try {
      const appId = parseInt(req.params.id);
      const { name, category, description, version,
              file_size, os, is_free, download_url, is_featured, is_active, icon_file_id } = req.body;
      const slug = makeSlug(name);

      await AppModel.update(appId, {
        name, slug, category,
        description,
        version: version || 'v1.0',
        file_size: file_size || '-',
        os: os || 'Windows',
        is_free: is_free === 'true',
        download_url: download_url.trim(),
        is_featured: is_featured === 'true',
        is_active: is_active === 'true',
        icon_file_id: icon_file_id ? icon_file_id.trim() : null
      });

      req.flash('success', `"${name}" imehariwiwa.`);
      res.redirect('/admin');
    } catch (err) {
      console.error('updateApp error:', err);
      req.flash('error', 'Hitilafu ya seva.');
      res.redirect(`/admin/apps/${req.params.id}/edit`);
    }
  },

  async deleteApp(req, res) {
    try {
      const appId = parseInt(req.params.id);
      const app = await AppModel.getById(appId);
      await AppModel.delete(appId);
      req.flash('success', `"${app?.name}" imefutwa.`);
      res.redirect('/admin');
    } catch (err) {
      console.error('deleteApp error:', err);
      req.flash('error', 'Hitilafu ya seva.');
      res.redirect('/admin');
    }
  },
};

module.exports = AdminController;